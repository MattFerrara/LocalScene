// server.js
import express from 'express'
import cors from 'cors'
import mongoose from 'mongoose'
import dotenv from 'dotenv'
import fetch from 'node-fetch'

dotenv.config()

const app = express()
const PORT = process.env.PORT || 3000

app.use(cors())
app.use(express.json())

// MongoDB connection
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('MongoDB connected'))
.catch(err => console.error('Mongo error:', err))

    // Schema and model
const concertSchema = new mongoose.Schema({
  band: String,
  address: String,
  town: String,
  state: String,
  venue: String,
  date: String,
  time: String,
  timeZone: String,
  utcTimestamp: String,
  price: Number,
  others: String,
  age: String,
  lat: Number,
  lon: Number,
  deleteAt: { type: Date, index: { expires: 0 } },
  createdAt: { type: Date, default: Date.now }
})


const Concert = mongoose.model('Concert', concertSchema)

// Helper: check if show is duplicate
const isDuplicate = async (data, utcTimestamp) => {
  const shows = await Concert.find({
    date: data.date,
    time: data.time,
    address: `${data.address}, ${data.town}, ${data.state}`
  })

  const newBands = new Set(
    [data.band, ...data.others.split(',').map(b => b.trim())].map(b => b.toLowerCase())
  )

  for (let show of shows) {
    const existingBands = new Set(
      [show.band, ...show.others.split(',').map(b => b.trim())].map(b => b.toLowerCase())
    )
    for (let band of newBands) {
      if (existingBands.has(band)) return true
    }
  }

  return false
}

// POST /api/concerts
app.post('/api/concerts', async (req, res) => {
  try {
    const data = req.body
    const fullAddress = `${data.address}, ${data.town}, ${data.state}`

    const geoRes = await fetch(`https://geocode.maps.co/search?q=${encodeURIComponent(fullAddress)}&api_key=${process.env.GEOCODE_KEY}`)
    const geo = await geoRes.json()
    if (!geo || geo.length === 0) throw new Error('Invalid address')

    const { lat, lon } = geo[0]

    const tzRes = await fetch(`http://api.timezonedb.com/v2.1/get-time-zone?key=${process.env.TZDB_KEY}&format=json&by=position&lat=${lat}&lng=${lon}`)
    if (!tzRes.ok) throw new Error('Timezone lookup failed')
    const tzData = await tzRes.json()
    if (!tzData.zoneName) throw new Error('Could not determine time zone')

    const pseudoUTC = new Date(`${data.date}T${data.time}:00Z`).getTime()
    const utcOffsetMillis = tzData.gmtOffset * 1000
    const utcTime = new Date(pseudoUTC - utcOffsetMillis)

    if (utcTime < Date.now()) return res.status(400).json({ error: 'Date/time is in the past' })

    const duplicate = await isDuplicate(data, utcTime.toISOString())
    if (duplicate) return res.status(400).json({ error: 'Duplicate show exists' })

    const concert = new Concert({
    ...data,
    address: fullAddress,
    lat,
    lon,
    timeZone: tzData.zoneName,
    utcTimestamp: utcTime.toISOString(),
    deleteAt: new Date(utcTime.getTime() + 60 * 60 * 1000) // correct placement
})


    await concert.save()
    res.status(201).json(concert)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// GET /api/concerts
app.get('/api/concerts', async (req, res) => {
  try {
    const now = new Date()
    const oneHourAgo = new Date(now.getTime() - 60 * 60 * 1000)
    const concerts = await Concert.find({ utcTimestamp: { $gte: oneHourAgo.toISOString() } })
    res.json(concerts)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})
app.get('/', (req, res) => res.send('Server and MongoDB are working'))

app.listen(PORT, () => console.log(`Server running on port ${PORT}`))
